# Joei’s story studio

A creative proposal from Frank: original robot companions, printable story prompts, portable assistant briefs and digital-product ideas.

The web companion is intended for https://frankx.ai/friends/joei. The page is a local interactive workflow preview; it does not run AI services. Copy a brief into the assistant you use, supply your approved material, and review the output. These prompts are usable instructions; the five illustrated roles are proposed responsibilities rather than deployed agents.

Start with story-spark-cards.md or open story-sparks.html and print the twelve original adult story prompts. They were created for this proposal and are not represented as Joei’s existing method.

## Crew

Echo: source and voice. Moss: circle preparation. Pip: coordination. Folio: product editions. Sunny: client handoff. All five are new original proposed character identities. No human in the artwork is represented as Joei or Frank. The story garden is an Arcanea-inspired collaboration concept, not established canon or an agreed partnership.

## Proposed products

- Pocket story deck: printable cards, test €19–29.
- A circle in a box: adult host pack, test €39–59.
- Speaker’s storybook: practice workbook, test €59–89.
- Stories at work: facilitator kit, test €149–249.

Price ranges are hypotheses. Validate usefulness, actual costs, licensing and owner approval before sale. No checkout offers are included.

## Files

Four portable command briefs; five assistant role briefs; twelve story cards; printable HTML deck; original crew and client-delivery artwork; exact SVG workflow infographic; generation prompts and a source manifest.

Public practice source: https://joei-chan.com/, retrieved 12 October 2026. Character references: original atelier image and the new crew-sheet edition. All generated art is proposal work. Mini Me Storyboard new-proposal workflow and Arcanean Art Director were used; no likeness anchors or owned character canon were loaded.

Human review decides what is published, sent to clients or sold. Keep the source, approval record and edition with each output.
