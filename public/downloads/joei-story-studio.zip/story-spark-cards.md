# Twelve story sparks

Original prototype by Frank's AI-assisted studio for Joei to review. These are not attributed to Joei's existing practice. Adult audience. Print, cut and pick one; sharing is optional.

1. **The tiny detail.** Tell us about a moment you remember through one small detail: a sound, a smell, a sleeve or a sentence.
2. **The object.** Choose an ordinary object that has travelled with you. When did it start to matter?
3. **The unexpected guest.** Recall a person who changed the atmosphere of a room. What did they actually do?
4. **The first attempt.** Tell us about trying something before you knew how. What surprised you?
5. **The detour.** When did a change of plan lead somewhere worth remembering?
6. **The sentence you kept.** Recall a sentence someone said that stayed with you. Where were you when you heard it?
7. **The place.** Describe a place through three details before telling us its name.
8. **A small kindness.** Tell us about a gesture that would be easy for everyone else to miss.
9. **The permission slip.** What did you finally let yourself try? Describe the first moment, rather than the whole journey.
10. **The funny mistake.** Share a harmless mix-up that still makes you smile. What did you think was happening?
11. **The returning thing.** What hobby, place or ritual found its way back into your life?
12. **The story still open.** Tell the beginning of something you are curious about. Leave the ending unwritten.

Host note: let each person choose or pass. Ask about a concrete detail before offering an interpretation. Do not record or reuse anyone's story without specific permission.
